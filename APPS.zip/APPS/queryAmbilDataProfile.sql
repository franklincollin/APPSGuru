SELECT s.nuptk, s.sandi, g.nama, g.tgl_lahir FROM `super_login` s, `guru` g WHERE s.nama_pengguna = "blackmask"; 
