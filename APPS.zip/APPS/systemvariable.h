#ifndef SYSTEMVARIABLE_H
#define SYSTEMVARIABLE_H

#include <QString>

class SystemVariable{
  public:
    QString schoolCode;
    QString nis;
};

#endif // SYSTEMVARIABLE_H
